<?php

namespace App\Http\Controllers\Auth;

use App\Models\Master\User;
use Illuminate\Http\Request;
use App\Http\Controllers\ResourceController;
use Auth;
use DB;
class UserController extends ResourceController
{
    public function home()
    {
        $applications           = array();
        $application_access     = 0;
        foreach (Auth::user()->applicationPermissions as $application_permission)
        {
            if ($application_permission->is_active)
            {
                if ($application_permission->application->is_active)
                {
                    $application_access++;
                    array_push($applications,$application_permission->application);
                }
            }
        }
        return view('home',['applications'=>$applications,'application_access'=>$application_access]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Master\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Master\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Master\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Master\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        //
    }
}
