<?php

namespace App\Http\Controllers;

use App\Models\Master\ApplicationPermission;
use Illuminate\Http\Request;

class ApplicationPermissionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Master\ApplicationPermission  $applicationPermission
     * @return \Illuminate\Http\Response
     */
    public function show(ApplicationPermission $applicationPermission)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Master\ApplicationPermission  $applicationPermission
     * @return \Illuminate\Http\Response
     */
    public function edit(ApplicationPermission $applicationPermission)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Master\ApplicationPermission  $applicationPermission
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ApplicationPermission $applicationPermission)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Master\ApplicationPermission  $applicationPermission
     * @return \Illuminate\Http\Response
     */
    public function destroy(ApplicationPermission $applicationPermission)
    {
        //
    }
}
