require('./bootstrap');
require('admin-lte/plugins/bootstrap/js/bootstrap.bundle.min.js');
require('admin-lte/dist/js/adminlte.min.js');
const Swal = window.Swal = require('sweetalert2');
