<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::middleware('auth')->group(function ()
    {
        Route::get('/home', 'Auth\UserController@home')->name('credential_access.home-page');

        Route::get('/ganti-password/{user_id}', 'Master\MasterApp\UserController@showChangePasswordForm')->name('users.change-password');

        Route::post('/proses-ganti-password', 'Master\MasterApp\UserController@processChangePassword')->name('users.process-change-password');
        Route::get('/user-guide', 'Auth\UserCredentialController@userGuide')->name('credential_access.user-guide');
        Route::get('/halaman-help', 'Auth\UserCredentialController@halamanHelp')->name('credential_access.help-page');
    }
);

Route::group(['prefix' => 'master-apps','middleware'=>['auth','credential.check']], function()
{
    Route::get('/', 'Masterapp\HomeController@index')->name('master_app.show_home');
});
